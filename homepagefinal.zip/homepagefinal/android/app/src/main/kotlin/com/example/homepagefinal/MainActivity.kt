package com.example.homepagefinal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
